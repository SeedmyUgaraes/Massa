namespace MassaKWin.Core
{
    public enum ScaleProtocol
    {
        Unknown = 0,
        WithTare = 1,
        WithoutTare = 2
    }
}
